﻿namespace Interfaces.Devices
{
    public interface IStatusBar
    {
        void Exibir();
        void Ocultar();
    }
}
