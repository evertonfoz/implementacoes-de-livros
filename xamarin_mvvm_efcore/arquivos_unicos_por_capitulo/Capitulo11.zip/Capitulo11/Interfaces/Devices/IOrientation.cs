﻿namespace CasaDoCodigo.Devices.Interfaces
{
    public interface IOrientation
    {
        void Landscape();
        void Portrait();
    }
}
