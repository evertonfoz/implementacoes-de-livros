﻿namespace CasaDoCodigo.DataAccess.Interfaces
{
    public interface IDBPath
    {
        string GetDbPath();
    }
}
